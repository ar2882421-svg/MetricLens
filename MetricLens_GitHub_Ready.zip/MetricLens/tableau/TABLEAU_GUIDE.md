# Tableau Guide — MetricLens

1. Upload your CSV or Excel dataset in MetricLens.
2. Review the data quality profile and choose any cleaning options.
3. In the Export Center, download **Tableau-ready CSV**.
4. Open Tableau Public or Tableau Desktop.
5. Select **Connect → Text File** and choose `cleaned_tableau_data.csv`.
6. Build worksheets using dimensions (categories/dates) and measures (numeric fields).
7. Select **Dashboard → New Dashboard**, then drag worksheets onto the canvas.
8. Add titles, filters, legends, and tooltips. Save your workbook.

**Important:** Tableau is connected to an exported CSV. It does not automatically sync with each new upload to MetricLens. Tableau Public workbooks are public, so do not publish confidential data.
